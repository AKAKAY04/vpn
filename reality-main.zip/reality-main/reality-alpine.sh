#!/bin/bash

# Initial Installation Dependencies
install_dependencies() {
    packages="gawk curl openssl"
    install=""

    for pkg in $packages; do
        if ! command -v $pkg &>/dev/null; then
            install="$install $pkg"
        fi
    done

    if [ -z "$install" ]; then
        echo -e "\e[1;32mAll packages are already installed\e[0m"
        return
    fi

    if command -v apt &>/dev/null; then
        pm="apt-get install -y -q"
    elif command -v dnf &>/dev/null; then
        pm="dnf install -y"
    elif command -v yum &>/dev/null; then
        pm="yum install -y"
    elif command -v apk &>/dev/null; then
        pm="apk add"
    else
        echo -e "\e[1;33m暂不支持的系统!\e[0m"
        exit 1
    fi
    $pm $install
}
install_dependencies

# Define Environment Variables
export PORT=${PORT:-$(shuf -i 2000-65000 -n 1)}
export FILE_PATH=${FILE_PATH:-'./app'}
export SNI=${SNI:-'www.yahoo.com'}
export UUID=$(openssl rand -hex 16 | awk '{print substr($0,1,8)"-"substr($0,9,4)"-"substr($0,13,4)"-"substr($0,17,4)"-"substr($0,21,12)}')

echo -e "\e[1;32mInstallation is in progress, please wait...\e[0m"

# Download Dependency Files
ARCH=$(uname -m)
DOWNLOAD_DIR="${FILE_PATH}"
mkdir -p "$DOWNLOAD_DIR"

# Define the common download link and file name
FILE_INFO=("https://github.com/flq367/reality/releases/download/amd64/xray web")

for entry in "${FILE_INFO[@]}"; do
    URL=$(echo "$entry" | cut -d ' ' -f 1)
    NEW_FILENAME=$(echo "$entry" | cut -d ' ' -f 2)
    FILENAME="$DOWNLOAD_DIR/$NEW_FILENAME"
    if [ -e "$FILENAME" ]; then
        echo -e "\e[1;32m$FILENAME already exists, Skipping download\e[0m"
    else
        curl -L -sS -o "$FILENAME" "$URL"
        echo -e "\e[1;32mDownloading $FILENAME\e[0m"
    fi
    chmod +x "$FILENAME"
done

# Generating Configuration Files
generate_config() {

    X25519Key=$(./"${FILE_PATH}/web" x25519)
    PrivateKey=$(echo "${X25519Key}" | head -1 | awk '{print $3}')
    PublicKey=$(echo "${X25519Key}" | tail -n 1 | awk '{print $3}')
    shortid=$(openssl rand -hex 8)

  cat > ${FILE_PATH}/config.json << EOF
{
    "inbounds": [
        {
            "port": $PORT,
            "protocol": "vless",
            "settings": {
                "clients": [
                    {
                        "id": "$UUID",
                        "flow": "xtls-rprx-vision"
                    }
                ],
                "decryption": "none"
            },
            "streamSettings": {
                "network": "tcp",
                "security": "reality",
                "realitySettings": {
                    "show": false,
                    "dest": "1.1.1.1:443",
                    "serverNames": [
                        "$SNI"
                    ],
                    "privateKey": "$PrivateKey",
                    "shortIds": [
                        "$shortid"
                    ]
                }
            }
        }
    ],
    "outbounds": [
        {
            "protocol": "freedom",
            "tag": "direct"
        },
        {
            "protocol": "blackhole",
            "tag": "blocked"
        }
    ]    
}
EOF
}
generate_config

# running files
run() {

  if [ -e "${FILE_PATH}/web" ]; then
    nohup "${FILE_PATH}/web" -c ${FILE_PATH}/config.json >/dev/null 2>&1 &
    sleep 1
    ps aux | grep "[w]eb" > /dev/null && echo -e "\e[1;32mweb is running\e[0m" || { echo -e "\e[1;35mweb is not running, restarting...\e[0m"; pkill -x "web"; nohup "${FILE_PATH}/web" -c ${FILE_PATH}/config.json >/dev/null 2>&1 & sleep 2; echo -e "\e[1;32mweb restarted\e[0m"; }
  fi

}
run

# get ip
IP=$(curl -s ipv4.ip.sb)

# get ipinfo
ISP=$(curl -s https://speed.cloudflare.com/meta | awk -F\" '{print $26"-"$18}' | sed -e 's/ /_/g')

cat > ${FILE_PATH}/list.txt <<EOF

vless://${UUID}@${IP}:${PORT}?encryption=none&flow=xtls-rprx-vision&security=reality&sni=${SNI}&fp=chrome&pbk=${PublicKey}&sid=${shortid}&type=tcp&headerType=none#$ISP

EOF
cat ${FILE_PATH}/list.txt
echo -e "\n\e[1;32m${FILE_PATH}/list.txt saved successfully\e[0m"
echo ""
echo -e "\n\e[1;32mInstall success!\e[0m"

exit 0
