一键reality脚本

```bash
bash <(curl -sL https://raw.githubusercontent.com/flq367/reality/main/r.sh)
```
